--[[----------------------------------------------------------------------------

	Implementation of the Yag Remote Protocol.

	Copyright (C) 2010 Michael Knoll <mimi@kaktusteam.de>

	Released under the GNU GPL.
	
	$Id: $
-----------------------------------------------------------------------------]]--

require 'TableUtils'
require 'StringUtils'
require 'HttpUtils'

  -- Lightroom SDK
local LrView = import 'LrView'
local LrFunctionContext = import 'LrFunctionContext'
local LrDialogs = import 'LrDialogs'
local LrLogger = import 'LrLogger'
local LrHttp = import 'LrHttp'
local LrTasks = import 'LrTasks'
local LrStringUtils = import 'LrStringUtils'
local LrPathUtils = import 'LrPathUtils'

local prefs = import 'LrPrefs'.prefsForPlugin()

local bind = LrView.bind
local share = LrView.share

  -- setup logger
local log = LrLogger( 'YagLogger' )

YagRemoteProtocol = {}

----------------------------------------------------------------------------------

--
-- Parses the gallery response by parsing JSON
--
local function parseGalleryResponse( raw )
	
	local result = Json.Decode(raw)
	return result

end



--
-- Tests a connection to a YAG server
--
function YagRemoteProtocol.testConnection( serverId ) 
	-- get server	
	local serverSettings = prefs.serverTable[serverId]
	local url = YagRemoteProtocol.constructURL(serverSettings)
	url = url .. '&tx_yag_pi1[controller]=Remote&tx_yag_pi1[action]=testConnection'
  	
	-- send GET request to the YAG server
	response = LrHttp.get(url)
	
	-- parse JSON reponse into table format
	responseTable = parseGalleryResponse(response)
		
	-- get server response status
	local serverStatus = responseTable['status']
	return serverStatus
end



--
-- Gets a list of galleries from server
--
function YagRemoteProtocol.getGalleries( serverId ) 
	local serverSettings = prefs.serverTable[serverId]
	local url = YagRemoteProtocol.constructURL(serverSettings)
	url = url .. '&tx_yag_pi1[controller]=Remote&tx_yag_pi1[action]=galleryList'

	--LrDialogs.message(url)

	response = LrHttp.get(url)
	responseTable = parseGalleryResponse(response)
	
	local serverStatus = responseTable['status']
	local galleries = responseTable['galleries']
	return serverStatus, galleries
end



--
-- Gets a list of albums from server
--
function YagRemoteProtocol.getAlbums(serverId, galleryValue)
	local serverSettings = prefs.serverTable[serverId]
	local url = YagRemoteProtocol.constructURL(serverSettings)
	url = url .. '&tx_yag_pi1[controller]=Remote&tx_yag_pi1[action]=albumList&tx_yag_pi1[galleryUid]=' .. galleryValue

	--LrDialogs.message(url)

	response = LrHttp.get(url)
	responseTable = parseGalleryResponse(response)
	
	local serverStatus = responseTable['status']
	local albums = responseTable['albums']
	return serverStatus, albums
end



--
-- Validates and creates a proper gallery/main.php URL
--
function YagRemoteProtocol.constructURL( serverSettings )
	-- the url to construct
	local url = ""

	server = LrStringUtils.trimWhitespace(serverSettings.server)
	
	if string.sub(server, 1, 7) ~= 'http://' then
		url = 'http://'
	end
	
	-- create valid server string
	if string.sub(server, -10) == '/index.php' then
		url = url..server
	elseif string.sub(server, -1) == '/' then
		url = url..server..'index.php'
	elseif string.sub(server, -1) ~= '/' then
		url = url..server..'/index.php'
	end
	
	-- add page UID
	url = url..'?id='..serverSettings.pageId
	
	return url
end



--
-- Upload a file to the gallery.
--
function YagRemoteProtocol.uploadImage(serverSettings, album, imagePath)
	log:trace("Calling GalleryRemoteProtocol.uploadImage( "..serverSettings.server..", "..album..", "..imagePath.." )")
	
	local filename = LrPathUtils.leafName( imagePath )
	local url = YagRemoteProtocol.constructURL(serverSettings)
	
	content = {
		-- TODO There should be a namespace used for that
		{ name = 'file',
		  fileName = filename,
		  filePath = imagePath,
		  contentType = 'multipart/form-data'
	    },
	    { name = 'tx_yag_pi1[filename]',
		  value = filename,
	      contentType = 'multipart/form-data'
	    },
	    { name = 'tx_yag_pi1[controller]',
	      value = 'Remote',
	      contentType = 'multipart/form-data'	
	    },
	    { name = 'tx_yag_pi1[action]',
	      value = 'addItemToAlbum',
	      contentType = 'multipart/form-data'	
	    },
	    { name = 'tx_yag_pi1[albumUid]',
	      value = album,
	      contentType = 'multipart/form-data'	
	    }
  	}
	 		
	-- send POST request to the gallery server
	local response, debug = LrHttp.postMultipart(url, content )
	
	-- parse reponse into easy to digest table format
	responseTable = parseGalleryResponse(response)
		
	-- get server response status
	local serverStatus = responseTable['status']
	return serverStatus
end
