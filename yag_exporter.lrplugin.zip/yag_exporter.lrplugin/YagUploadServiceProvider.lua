--[[----------------------------------------------------------------------------

	Definition of the Yag Export Service Provider.

	Copyright (C) 2010 Michael Knoll <mimi@kaktusteam.de>

	Released under the GNU GPL.

	$Id:$

-----------------------------------------------------------------------------]]--

	-- Lightroom SDK
local LrView = import 'LrView'

	-- GalleryUpload plugin
require 'YagUploadExportDialogSections'
require 'YagUploadTask'
require 'LoggerConfig'

--============================================================================--

return {
	
	hideSections = { 'exportLocation', 'postProcessing' },

	allowFileFormats = { 'JPEG' },
	allowColorSpaces = { 'sRGB' },
	
	hidePrintResolution = true,
	
	image = "kaktusteam.png",
	
	exportPresetFields = {
		{ key = 'serverValue', default = '' },
		{ key = 'showInBrowser', default = false },
	},
	
	startDialog = YagUploadExportDialogSections.startDialog,
	sectionsForTopOfDialog = YagUploadExportDialogSections.sectionsForTopOfDialog,
	
	processRenderedPhotos = YagUploadTask.processRenderedPhotos,
	
}
