--[[---------------------------------------------------------------------------

	Configure the logging facility

	Copyright (C) 2010 Michael Knoll <mimi@kaktusteam.de>

	Released under the GNU GPL.

	$Id: $

---------------------------------------------------------------------------]]--

local LrLogger = import "LrLogger"
local log = LrLogger( 'YagLogger' )

log:enable( { 
	['debug'] = 'logfile',
	['trace'] = 'logfile',
	['info'] = 'logfile',
	['warn'] = 'logfile',
	['error'] = 'logfile',
	['fatal'] = 'logfile'
} )

log:disable()
