--[[----------------------------------------------------------------------------

	Readme file for the Lightroom to Gallery Export plugin.

	Released under the GNU GPL.

----------------------------------------------------------------------------]]--

==== Usage ====
  To use the plugin, copy the contained folder "gallery_upload.lrplugin" to 
  your Lightroom root directory.

  In order to activate the plugin inside Lightroom go to "Export" and select the
  plugin from the list of available plugins in the top right corner.
  
==== Support the development ====
  https://sourceforge.net/projects/lr-to-gallery/

  Visit the homepage to participate in the development of the plugin. We need 
  YOU to provide feedback. :)