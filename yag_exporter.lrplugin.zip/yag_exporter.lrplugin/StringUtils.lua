--[[----------------------------------------------------------------------------

	Utility functions for string processing.

	Copyright (C) 2007-2008 Moritz Post <mail@moritzpost.de>

	Released under the GNU GPL.

	$Id: StringUtils.lua 28 2008-11-09 11:22:04Z soulybouly $

-----------------------------------------------------------------------------]]--

--
-- Split the string _str into tokens separated by _sep
-- _firstOnly is optional and defines, whether the split takes place
-- for the first separator found or for fall occurrences (defaults to false)
--
function string.split( _str, _sep, _firstOnly) 
	local t = {}
	local sep = _sep
	if _sep == nil then 
		sep = "%s+"
	end 
	-- do first split
	while true do
		local from, to = string.find(_str, sep)
		if from then
			table.insert(t, string.sub(_str, 1, from-1))
			_str = string.sub(_str, to+1)
			-- get out of here if we only want to split first occurrence
		else
			break
		end
		if _firstOnly then break end
	end
	table.insert(t, _str)
	return t
end

--
-- Remove all backslashes before the given set of characters
--
function string.unescape(str, charSet)
	if not str then return "" end
	if not charSet then return str end
	return string.gsub(str, "\\("..charSet..")", "%1")
end

