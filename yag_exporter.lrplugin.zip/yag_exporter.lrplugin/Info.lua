--[[----------------------------------------------------------------------------

	Definition of the YAG export plugin.

	Copyright (C) 2010 Michael Knoll <mimi@kaktusteam.de>
	
	Released under the GNU GPL.

	$Id:$

-----------------------------------------------------------------------------]]--

return {
	
	LrSdkVersion = 1.3,
	LrSdkMinimumVersion = 1.3, -- minimum SDK version required by this plugin

	LrToolkitIdentifier = 'de.kaktusteam.mimi.lightroom.yagexporter',
	
	LrPluginName = 'YAG Exporter',
		
	-- Add the menu item to the File menu
	LrExportServiceProvider = {
		title = "Export to YAG",
		file = "YagUploadServiceProvider.lua",
	},
	
}


	