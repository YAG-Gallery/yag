--[[----------------------------------------------------------------------------

	Implementation of the upload facilities to the remote Gallery.

	Copyright (C) 2007-2008 Moritz Post <mail@moritzpost.de>

	Released under the GNU GPL.

	$Id: YagUploadTask.lua 28 2008-11-09 11:22:04Z soulybouly $

-----------------------------------------------------------------------------]]--

	-- Lightroom API
local LrPathUtils = import 'LrPathUtils'
local LrFtp = import 'LrFtp'
local LrFileUtils = import 'LrFileUtils'
local LrErrors = import 'LrErrors'
local LrDialogs = import 'LrDialogs'
local LrHttp = import 'LrHttp'

local prefs = import 'LrPrefs'.prefsForPlugin()

--============================================================================--

YagUploadTask = {}

--------------------------------------------------------------------------------

function YagUploadTask.processRenderedPhotos( functionContext, exportContext )

	-- Make a local reference to the export parameters.
	local exportSession = exportContext.exportSession
	local exportParams = exportContext.propertyTable
	
	-- Set progress title.
	local nPhotos = exportSession:countRenditions()

	-- get server
	serverId = exportParams.serverValue
	server = prefs.serverTable[serverId].server
	serverSettings = prefs.serverTable[serverId]
	
	-- get album
	albumUid = exportParams.albumValue
	
	local progressScope = exportContext:configureProgress{
						title = nPhotos > 1
							and LOC( "$$$/YagUpload/Upload/Progress=Uploading ^1 photos to the Gallery", nPhotos )
							or LOC "$$$/YagUpload/Upload/Progress/One=Uploading one photo to the Gallery",
					}

	
	
	-- Iterate through photo renditions.
	local failures = {}

	for i, rendition in exportContext:renditions{ stopIfCanceled = true } do
	
		-- Get next photo.
		local photo = rendition.photo
		local success, pathOrMessage = rendition:waitForRender()
		
		-- Check for cancellation again after photo has been rendered.
		if progressScope:isCanceled() then
			break
		 end
		
		if success then

			local filename = LrPathUtils.leafName( pathOrMessage )

			-- upload file to gallery
			--success = YagRemoteProtocol.uploadImage(server, albumUid, pathOrMessage)
			success = YagRemoteProtocol.uploadImage(serverSettings, albumUid, pathOrMessage)
			
			-- This has to be a number here, as JSON "0" converts to int(0)
			if success ~= 0 then
				-- if we can't upload that file, log it.  For example, maybe user has exceeded disk
				-- quota, or the file already exists and we don't have permission to overwrite, or
				-- we don't have permission to write to that directory, etc....
				LrDialogs.message('Hier darf ich nicht rein!')
				table.insert( failures, filename )
			end
					
			-- When done with photo, delete temp file. There is a cleanup step that happens later,
			-- but this will help manage space in the event of a large upload.
			
			LrFileUtils.delete( pathOrMessage )
					
		end
		
	end

	if #failures > 0 then
		local message
		if #failures == 1 then
			message = LOC "$$$/YagUpload/Upload/Errors/OneFileFailed=A file failed to upload correctly."
		else
			message = LOC ( "$$$/YagUpload/Upload/Errors/SomeFileFailed=^1 files failed to upload correctly.", #failures )
		end
		LrDialogs.message( message, table.concat( failures, "\n" ) )
	else
		-- show album in browser if desired
		if exportParams.showInBrowser == true then
			--LrHttp.openUrlInBrowser(GalleryRemoteProtocol.constructURL(server).."?g2_itemId="..albumName)	
			LrDialogs.message('TODO: make album open up in browser')
		end
	end
	
end
