--[[---------------------------------------

Provide Http helpers

Copyright (C) 2007-2008 Lars Heller <lhe@users.sourceforge.net>

Released under the GNU GPL.

$Id: HttpUtils.lua 28 2008-11-09 11:22:04Z soulybouly $

---------------------------------------]]--

-- put function inside this table
HttpUtils = {}

  -- setup logger
local LrLogger = import 'LrLogger'
local log = LrLogger( 'GalleryLogger' )
--
-- Private function to convert decimal numbers to hex representation
--
local function dec2hex(n)
    local base = 16
	local chars = "0123456789ABCDEF"
	local result = ""
	local d = 0
    while n > 0 do
        n, d = math.floor(n/base), math.mod(n, base) + 1
        result = string.sub(chars, d, d)..result
    end
    return result
end

--
-- URL encode a string - replace every space with "+" and all other
-- non-alphnumerical characters with their "%XX" notation, with XX being
-- the hexadecimal value of the ASCII-character
--
function HttpUtils.encode(str)
	if not str then return "" end
	-- replace everything except alphanumerical and space
	str = string.gsub(str, "[^%a%d ]", function (s)
		s = dec2hex(string.byte(s))
		if string.len(s) == 1 then
			s = "0"..s
		end
		s = "%"..s
		return s
	end)
	-- replace spaces with "+"
	str = string.gsub(str, " ", "+")
	return str
end


--
-- Transform HTMl entities into their character representation.
-- e.g. "&lt;" -> "<"
--
function HttpUtils.resolveEntities(str)
	if not str then 
		str = ""
	else
		log:debug("resolveEntities: str="..str)
		str = string.gsub(str, "&%a+;", {
			["&quot;"] = '"',
			["&amp;"] = "&",
			["&lt;"] = "<",
			["&gt;"] = ">"
		} )
	end
	log:debug("resolveEntities: result="..str)
	return str;
end
