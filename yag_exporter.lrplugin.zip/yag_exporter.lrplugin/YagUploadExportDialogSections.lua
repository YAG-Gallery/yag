--[[----------------------------------------------------------------------------

	Implementation of the sections shown in the Export dialog.

	Copyright (C) 2010 Michael Knoll <mimi@kaktusteam.de>

	Released under the GNU GPL.

	$Id: $

-----------------------------------------------------------------------------]]--

require 'YagUploadDialogs'
require 'YagRemoteProtocol'
require 'TableUtils'
require 'ViewUtils'
require 'Json'

	-- Lightroom SDK
local LrBinding = import 'LrBinding'
local LrView = import 'LrView'
local LrDialogs = import 'LrDialogs'
local LrTasks = import 'LrTasks'
local LrFunctionContext = import 'LrFunctionContext'
local LrLogger = import 'LrLogger'

local prefs = import 'LrPrefs'.prefsForPlugin()

 -- setup logger
local log = LrLogger( 'YagLogger' )

--============================================================================--

YagUploadExportDialogSections = {}

-------------------------------------------------------------------------------

local updateServerSelectionStatus = function( properties )
	
	properties.serverEnabled = false
	if #properties.serverItems > 0 then
		properties.serverEnabled = true
	end
	
	if properties.serverValue ~= 0 then
		properties.serverSelected = true
		--properties.serverSynopsis = prefs.serverTable[properties.serverValue].label
	else
		properties.serverSelected = false
		properties.albumsEnabled = false
		properties.albumItems = false
		properties.serverSynopsis = nil
		updateAlbumSelectionStatus( properties )
	end
end



function updateGallerySelectionStatus( properties )
	if properties.galleryValue == nil or properties.galleryValue == 0 then
		properties.gallerySelected = false
		properties.Lr_canExport = false
	else 
		properties.gallerySelected = true
	end

end



function updateAlbumSelectionStatus( properties )
	if properties.albumValue == nil or properties.albumValue == 0 then
		properties.albumSelected = false
		-- disable export button
		properties.LR_canExport = false
	else
		properties.albumSelected = true
		
		-- enable export button
		properties.LR_canExport = true
	end
end 



local buildServerItems = function( properties ) 
	properties.serverItems = {}
	
	if prefs == nil then
		log:info("No preferences")
	else
		if prefs.serverTable ~= nil and #prefs.serverTable > 0 then
			
			for i,v in ipairs(prefs.serverTable) do 
				table.insert(properties.serverItems,
					{ title = v.label, value = i }
				)
			end
		else
			-- select no server
			properties.serverValue = 0
		end
	end
	
	-- ensure notification mechanism
	properties.serverItems = properties.serverItems
end



local buildGalleryItems = function( properties, galleriesList )
	properties.galleryItems = {}

	if #galleriesList ~= 0 then
		for i,v in ipairs(galleriesList) do
			table.insert(properties.galleryItems, {title = v.name, value = v.uid})
		end	
			
	else 
		properties.galleryValue = 0
	end

	-- WTF
	properties.galleryAccountStatus = 'Connection established!'
	properties.galleryItems = properties.galleryItems
end



local buildAlbumItems = function( properties, albumList )
	properties.albumItems = {}
	for i, album in ipairs(albumList) do
		table.insert(properties.albumItems, {title = album.name, value = album.uid})
	end
	
	if properties.albumItems == 0 then
		properties.albumsEnabled = false
		properties.albumItems = false
		properties.galleryAccountStatus = 'Not logged in'
	else
		properties.galleryAccountStatus = 'Connection established!'
		properties.albumsEnabled = true
		properties.albumItems = properties.albumItems
	end
end


-------------------------------------------------------------------------------

function YagUploadExportDialogSections.startDialog( properties )
	
	-- disable export button
	properties.LR_canExport = false
	
	-- register observers
	properties:addObserver( 'serverValue', updateServerSelectionStatus )
	properties:addObserver( 'galleryValue', updateGallerySelectionStatus )
	properties:addObserver( 'albumValue', updateAlbumSelectionStatus )
	
	-- clear the gallery list
	properties.galleriesEnabled = false
	properties.galleryItems = false
	
	-- clear the album list
	properties.albumsEnabled = false
	properties.albumItems = false
	
	-- initialize components
	buildServerItems( properties )
	updateServerSelectionStatus( properties )
	updateGallerySelectionStatus( properties )
	updateAlbumSelectionStatus( properties )
end



-------------------------------------------------------------------------------

function YagUploadExportDialogSections.sectionsForTopOfDialog( f, properties )

	local f = LrView.osFactory()
	local bind = LrView.bind
	local share = LrView.share

	local result = {
	
		{ -- Server settings
		
			title = 'YAG Server Accounts',
			
			synopsis = bind { key = 'serverSynopsis', object = properties },
			
			f:row {	
				
				f:static_text { -- Label for selecting server
					width = share 'labelWidth',
					alignment = 'right',
					title = 'Server:',
				},
				
				f:popup_menu { -- Dropdown list for selecting server
					enabled = bind 'serverEnabled',
					title = bind 'serverTitle',
					items = bind 'serverItems',
					value = bind 'serverValue',
					fill_horizontal = 1	
				},
				
				f:push_button { -- Test connection status
					enabled = bind 'serverEnabled',
					title = 'Login!',
					action = function ( button )
						
						LrFunctionContext.postAsyncTaskWithContext ( 'LoadGalleries', function( context )
							-- Do test-login on server to check connection settings
							properties.galleryAccountStatus = 'Trying to connect to server!'
							local result = YagRemoteProtocol.testConnection(properties.serverValue)
							if result == '0' then
								properties.galleryAccountStatus = 'Loading galleries from server!'
								-- Load galleries from server
								local galleriesList = {}
								local responseStatus, galleriesList = YagRemoteProtocol.getGalleries(properties.serverValue)
								
								if #galleriesList == 0 then
									LrDialogs.message('No galleries were found on server!')
								else
									buildGalleryItems(properties,galleriesList)
									properties.galleriesEnabled = true
								end
								
							else 
								properties.galleryAccountStatus = 'Connection refused!'
							end
							
						end
						)
					end
				}	
			},
			
			f:row {	
				f:spacer {
					width = share 'labelWidth',
				},
				f:static_text { -- Status message
					title = bind 'galleryAccountStatus',
				},
				
				f:push_button {
					alignment = 'right',
					title = LOC "$$$/YagUpload/ExportDialog/AddServer=Add Server",
					action = function( button )
						local result = YagUploadDialogs.showManageServers()
						buildServerItems( properties )
						
						-- select the just added server in the popup_menu
						if result ~= "cancelled" then
							properties.serverValue = #prefs.serverTable
						end
						
						updateServerSelectionStatus( properties )
						
						-- ensure notification mechanism
						properties.serverItems = properties.serverItems
						
						buildAlbumItems( properties, {} )
					end
				},
				
				f:push_button {
					alignment = 'right',
					title = LOC "$$$//ExportDialog/ModifyServer=Modify Server",
					enabled = bind 'serverSelected',
					action = function( button )
						YagUploadDialogs.showManageServers(properties.serverValue)
						buildServerItems( properties )
						updateServerSelectionStatus( properties )
						
						buildAlbumItems( properties, {} )
					end
				},
				
				f:push_button {
					alignment = 'right',
					title = LOC "$$$//ExportDialog/DeleteServer=Delete Server",
					enabled = bind 'serverSelected',
					action = function( button )
						log:info("Removing server no "..properties.serverValue.." from serverTable")
						table.remove(prefs.serverTable, properties.serverValue)
						
						-- ensure storage in prefs
						prefs.serverTable = prefs.serverTable
						
						buildServerItems( properties )
						
						-- set selected item in popup_menu
						if properties.serverValue > 1 then
							properties.serverValue = properties.serverValue - 1
						elseif #properties.serverTable == 1 then
							properties.serverValue = 1
						else
							properties.serverValue = 0
						end
						
						updateServerSelectionStatus( properties )
						
						-- ensure notification mechanism
						properties.serverItems = properties.serverItems
						
						buildAlbumItems( properties, {} )
					end
				}
			},
		},
		
		{ -- Gallery settings
		
			title = 'Galleries on YAG server',
			
			synopsis = bind { key = 'galleryTitle', object = properties },
			
			f:row {
				
				f:static_text {
					title = 'Galleries on server:',
					alignment = 'right',
					width = share 'labelWidth',
					enabled = bind 'galleriesEnabled'
				},
				
				f:popup_menu {
					fill_horizontal = 1,
					enabled = bind 'galleriesEnabled',
					items = bind 'galleryItems',
					value = bind 'galleryValue',
					title = bind 'galleryTitle'
				},
				
				f:push_button {
					title = 'Select Gallery',
					enabled = bind 'galleriesEnabled',
					action = function (button)
						LrFunctionContext.postAsyncTaskWithContext ( 'SelectGallery', function( context )
							properties.galleryAccountStatus = 'Loading albums list!'
							local albumsList = {}
							local responseStatus, albumsList = YagRemoteProtocol.getAlbums(properties.serverValue, properties.galleryValue)
							
							if #albumsList == 0 then
								LrDialogs.message('No albums were found on server!')
							else
								buildAlbumItems(properties, albumsList)
								properties.albumsEnabled = true
								
								updateGallerySelectionStatus( properties )
						
								-- ensure notification mechanism
								properties.albumItems = properties.albumItems
							end
						end 
						)
					end
				}
			}	
		},
		 
		{  -- Album settings
		
			title = LOC "Albums in Gallery",
			
			synopsis = bind { key = 'albumTitle', object = properties },
			
			f:row {
				
				f:static_text {
					title = LOC "$$$//ExportDialog/Albums=Albums:",
					alignment = 'right',
					width = share 'labelWidth',
					enabled = bind 'albumsEnabled',
				},
				
				f:popup_menu {
					fill_horizontal = 1,
					enabled = bind 'albumsEnabled',
					items = bind 'albumItems',
					value = bind 'albumValue',
					title = bind 'albumTitle',
				},

				
				--[[ This button is not required any more, as we can make a selection in the dropdownlist
					 Can be used to 'add' an album out of LightRoom later on
				
				f:push_button {
					title = 'Select album',
					enabled = bind 'albumsEnabled',
					width = share "rightButtonWidth",
					action = function( button )
						LrFunctionContext.postAsyncTaskWithContext ( 'AddAlbum', function( context )
						
							resultAlbumName, resultAlbumTitle, resultAlbumDesc = YagUploadDialogs.showAddAlbum(context)
							
							if resultAlbumName ~= 'cancelled' then
								local status, actualAlbumName = GalleryRemoteProtocol.addAlbum(properties.serverValue,
																							   properties.albumValue,
																							   resultAlbumName, 
																							   resultAlbumTitle,
																							   resultAlbumDesc)
								
								local albumList = {}
								if status == '0' then
									status, albumList = GalleryRemoteProtocol.getAlbumList(properties.serverValue)
								end
								
								if status == '0' and #albumList > 0 then
									buildAlbumItems(properties, albumList)
									properties.albumsEnabled = true
									properties.albumValue = actualAlbumName
								else
									properties.albumsEnabled = false
									properties.albumItems = false
								end 
							end
						end )
					end
				},--]]
				
			},
			
				
			f:row {
				f:spacer {
					width = share 'labelWidth',
				},
				f:checkbox {
					title = LOC "$$$//ExportDialog/ShowInBrowser=Show Album in Browser After Upload",
					enabled = bind 'albumsEnabled',
					value = bind 'showInBrowser',
				},
			},
		}
	}
	
	return result
	
end
