--[[---------------------------------------

Provide helpers concerning the view

Copyright (C) 2007-2008 Lars Heller <lhe@users.sourceforge.net>

Released under the GNU GPL.

$Id$

---------------------------------------]]--

-- put functions inside this table
ViewUtils = {}

--
-- When displaying strings in a list, LR seems to interpret "&" in some way,
-- so this has to be escaped. Doubling an ampersand semms to help.
--
function ViewUtils.escapeForDisplay(str)
	if not str then
		return ""
	else
		return string.gsub(str, "&", "&&")
	end
end
